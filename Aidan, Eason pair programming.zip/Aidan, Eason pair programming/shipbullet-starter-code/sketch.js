// OOP Pair Programming Starter Code
// Aidan, Eason
// 25 november, 2022


// ------------------------------------------------------------------------- //
// You don't need to edit this section...

let enterprise;
let shipImage, bulletImage;
let bulletArray = [];

function preload() {
  shipImage = loadImage("assets/enterprise.png");
  bulletImage = loadImage("assets/laser-shot.png");
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  enterprise = new Ship(width/2, height/2, shipImage, bulletImage);
}

function draw() {
  background("black");
  enterprise.update();
  enterprise.display();
}

function keyPressed() {
  enterprise.handleKeyPress();
}

// ------------------------------------------------------------------------- //
// Start editing here!

class Ship {
  constructor(x, y, theImage, bulletImg) {
    // define the variables needed for this ship
    this.x = x;
    this.y = y;
    this.dx = 5;
    this.dy = 5;
    this.width = 50;
    this.height = 100;
    this.image = theImage;
    this.bulletImg = bulletImg;
  }

  update() {
    // move ship -- you might want to use the keyIsDown() function here
    if(keyIsDown(LEFT_ARROW) || keyIsDown(65)){
      this.x -= this.dx;
    }
    else if(keyIsDown(RIGHT_ARROW) || keyIsDown(68)){
      this.x += this.dx;
    }
    if(keyIsDown(UP_ARROW) || keyIsDown(87)){
      this.y -= this.dy;
    }
    if(keyIsDown(DOWN_ARROW) || keyIsDown(83)){
      this.y += this.dy;
    }
    // if doing extra for experts, show bullet(s)
    for (let i = bulletArray.length-1; i>0; i--) {
      if(!bulletArray[i].isOnScreen()){
        bulletArray.splice(i, 1);
      }
      else {
        bulletArray[i].update(); 
        bulletArray[i].display();
      }
    }
  }

  display() {
    // show the ship
    image(this.image, this.x, this.y, this.width, this.height);
  }

  handleKeyPress() {
    // you only need to use this if you are doing the extra for experts...
    // if you are, you should make a bullet if the space key was pressed
    if(keyIsDown(32)){
      bulletArray.push(new Bullet(this.x + this.width/2, this.y - this.height/10, 0, 1, this.bulletImg));
    }
  }
}

// ------------------------------------------------------------------------- //

// Extra for Experts 
//  - you can instantiate a bullet (or a bullet array) within the Ship class,
//    and call the display and update functions in the logical location of the 
//    Ship class. If you create an array of bullets, you might want to think about
//    when the bullets should be removed from the array...

class Bullet {
  constructor(x, y, dx, dy, theImage) {
    // define the variables needed for the bullet here
    this.x = x;
    this.y = y;
    this.dx = dx;
    this.dy = dy;
    this.image  = theImage;
    this.width = 5;
    this.height = 10;
  }

  update() {
    // what does the bullet need to do during each frame? how do we know if it is off screen?
    this.y -= this.dy;
  }

  display() {
    // show the bullet
    image(this.image, this.x, this.y, this.width, this.height);
  }

  isOnScreen() {
    // check if the bullet is still on the screen
    return this.y >= 0;
  }
}

